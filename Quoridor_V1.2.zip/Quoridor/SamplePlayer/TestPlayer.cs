﻿﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Procon2018.GameSystem;
using System.Diagnostics;
using System.Threading;

namespace Procon2018.GameInformation
{
    public class aTestPlayer : AbstractPlayer
    {
        int p1w = 0;
        int p2w = 0;


        public aTestPlayer() : base()
        {

        }

        public aTestPlayer(string name) : base()
        {
            this.name = name;
        }

        public override Dicision getDicision()
        {
            
            int seed = new Random().Next();
            seed = seed % 2;
            Thread.Sleep(20);
            Dicision outdic = new Dicision();
            // 0 移動のみ　1壁のみ 2移動+壁
            //Debug.WriteLine("dic_label:{0}\n", seed);

            getwallnum();
            if(p1w == 0 && p2w == 0)
            {
                seed = 0;
            }
            switch (seed)
            {
                case 0:
                    outdic.DL= Dicision_label.dic_pawnmove;
                    Debug.Write("Rdmoveeeeeeeeeeeee");
                    outdic.PM = Rdmove();
                    break;
                case 1:
                    outdic.DL = Dicision_label.dic_wallset;
                    Debug.Write("Wallsetttttttttttt");
                    outdic.WS = Rdwallset();
                    break;
                default:
                    System.Random rnum = new System.Random(1300);
                    int rdnum = rnum.Next(2);
                    switch (rdnum)
                    {
                        case 0:
                            outdic.DL = Dicision_label.dic_pawnmove;
                            outdic.PM = Rdmove();
                            break;
                        case 1:
                            outdic.DL = Dicision_label.dic_wallset;
                            outdic.WS = Rdwallset();
                            break;
                        default:
                            outdic.DL = Dicision_label.dic_wallset;
                            outdic.WS = Rdwallset();
                            break;
                    }
                    break;
                    
            }
            return outdic;
        }

        private PawnMove Rdmove()
        {
            Debug.Write("fuck");
            int seed1 = wheretomove();
            Debug.WriteLine("PawnMove:{0}\n", seed1);
            Thread.Sleep(20);
            switch (seed1)
            {
                case 0:
                    return PawnMove.Up;
                case 1:
                    return PawnMove.Down;
                case 2:
                    return PawnMove.Left;
                case 3:
                    return PawnMove.Right;
                case 4:
                    return PawnMove.Upper_left;
                case 5:
                    return PawnMove.Upper_right;
                case 6:
                    return PawnMove.Lower_left;
                case 7:
                    return PawnMove.Lower_right;
                default:
                    return PawnMove.Up;
            }
        }

        private WallSet Rdwallset()
        {
            Debug.Write("fuckfuck");
            int seed2 = new Random().Next();
            seed2 = seed2 % 2                ;
            Thread.Sleep(20);
            int seed3 = new Random().Next();
            seed3 = seed3 % 8;
            Thread.Sleep(20);

            int seed4 = new Random().Next();
            seed4 = seed4 % 8;
      
            Debug.WriteLine("Pos:({0},{1}),Dir:{2}\n", seed3, seed4, seed2);
            //int mmdnum = int.Parse(Console.ReadLine());//rnd.Next(9);
            //int mmdnum2 = int.Parse(Console.ReadLine());//(mmdnum + mmdnum) % 9;
            WallSet mmws = new WallSet(new Position(seed3,seed4), WallDir.blank);
            //int a = int.Parse(Console.ReadLine());
            //tmp =Console.ReadLine();
             switch (seed2)
            {
                case 0:
                    mmws.WD = WallDir.Horizontal2Goal;
                    break;
                case 1:
                    mmws.WD = WallDir.Vertical2Goal;
                    break;
                default:
                    mmws.WD = WallDir.Horizontal2Goal;
                    break;
            }

            return mmws;
        }


        private void getwallnum()
        {
            p1w = GetWallnum(FieldObject.P1);
            p2w = GetWallnum(FieldObject.P2);
        }


        private int wheretomove()
        {
            Position mypos = GetPawnpos(FieldObject.P1);
            Position enemypos = GetPawnpos(FieldObject.P2);
            int seed1 = new Random().Next();

            // 相手と自分の距離
            double distance = Math.Pow(mypos.Row - enemypos.Row, 2) + Math.Pow(mypos.Col - enemypos.Col, 2);
            if ( distance != 1) //隣接でなければ飛ばしはしない
            {
                seed1 = seed1 % 4;
            }
            else
            {
                seed1 = seed1 % 8;
            }
            return seed1;
        }
        /// <summary>
        /// 指定した方向に移動可能かチェック
        /// </summary>
        /// <param name="PM">
        /// PM : 移動方向
        /// </param>
        /// <returns>
        /// true : 移動可能
        /// false : 移動不可能
        /// </returns>
        /*private bool CheckMove(PawnMove PM)
        {
            Position Mypos = new Position(0, 0);
            Position Enemypos = new Position(0, 0);
            Mypos = GetPawnpos(FieldObject.P1);
            Enemypos = GetPawnpos(FieldObject.P2);


            Position OutPos = new Position(-1, -1);

            if (Mypos.Col == 8 && (PM == PawnMove.Right || PM == PawnMove.Lower_right || PM == PawnMove.Upper_right)) return false;
            else if (Mypos.Col == 0 && (PM == PawnMove.Left || PM == PawnMove.Lower_left || PM == PawnMove.Upper_left)) return false;
            else if (Mypos.Row == 8 && (PM == PawnMove.Down || PM == PawnMove.Lower_left || PM == PawnMove.Lower_right)) return false;
            else if (Mypos.Row == 0 && (PM == PawnMove.Up || PM == PawnMove.Upper_left || PM == PawnMove.Upper_right)) return false;

            switch (PM)
            {//横壁：gamestate.Wc_Row 縦壁:gamestate.Wc_Col
                case PawnMove.Upper_right:
                    if (Mypos.Row == Enemypos.Row && (Enemypos.Col - Mypos.Col == 1) && gamestate.Wc_Row[Mypos.Row - 1, Mypos.Col + 1] == WallClass.blank)
                        return true;
                    else if (Mypos.Col == Enemypos.Col && (Mypos.Row - Enemypos.Row == 1) && gamestate.Wc_Col[Mypos.Row - 1, Mypos.Col] == WallClass.blank)
                        return true;
                    else
                        return false;

                case PawnMove.Upper_left:
                    if (Mypos.Row == Enemypos.Row && (Mypos.Col - Enemypos.Col == 1) && gamestate.Wc_Row[Mypos.Row - 1, Mypos.Col - 1] == WallClass.blank)
                        return true;
                    else if (Mypos.Col == Enemypos.Col && (Mypos.Row - Enemypos.Row == 1) && gamestate.Wc_Col[Mypos.Row - 1, Mypos.Col - 1] == WallClass.blank)
                        return true;
                    else
                        return false;
                case PawnMove.Lower_left:
                    if (Mypos.Row == Enemypos.Row && (Mypos.Col - Enemypos.Col == 1) && gamestate.Wc_Row[Mypos.Row, Mypos.Col - 1] == WallClass.blank)
                        return true;
                    else if (Mypos.Col == Enemypos.Col && (Enemypos.Row - Mypos.Row == 1) && gamestate.Wc_Col[Mypos.Row + 1, Mypos.Col - 1] == WallClass.blank)
                        return true;
                    else
                        return false;
                case PawnMove.Lower_right:
                    if (Mypos.Row == Enemypos.Row && (Enemypos.Col - Mypos.Col == 1) && gamestate.Wc_Row[Mypos.Row, Mypos.Col + 1] == WallClass.blank)
                        return true;
                    else if (Mypos.Col == Enemypos.Col && (Enemypos.Row - Mypos.Row == 1) && gamestate.Wc_Col[Mypos.Row + 1, Mypos.Col] == WallClass.blank)
                        return true;
                    else
                        return false;

                case PawnMove.Up:
                    if (gamestate.Wc_Row[Mypos.Row - 1, Mypos.Col] == WallClass.exist)
                        return false;
                    else if (Mypos.Col == Enemypos.Col && (Mypos.Row - Enemypos.Row == 1))
                    {
                        if (Mypos.Row < 2)
                        {
                            return false;
                        }
                        else if (gamestate.Wc_Row[Mypos.Row - 2, Mypos.Col] == WallClass.exist)
                        {
                            return false;
                        }
                        else return true;
                    }
                    else
                        return true;
                case PawnMove.Down:
                    if (gamestate.Wc_Row[Mypos.Row, Mypos.Col] == WallClass.exist)
                        return false;
                    else if (Mypos.Col == Enemypos.Col && (Enemypos.Row - Mypos.Row == 1))
                    {
                        if (Mypos.Row > 6)
                        {
                            return false;
                        }
                        else if (gamestate.Wc_Row[Mypos.Row + 1, Mypos.Col] == WallClass.exist)
                        {
                            return false;
                        }
                        else return true;
                    }
                    else
                        return true;

                case PawnMove.Left:
                    if (gamestate.Wc_Col[Mypos.Row, Mypos.Col - 1] == WallClass.exist)
                        return false;
                    else if (Mypos.Row == Enemypos.Row && (Mypos.Col - Enemypos.Col == 1))
                    {
                        if (Mypos.Col < 2)
                        {
                            return false;
                        }
                        else if (gamestate.Wc_Col[Mypos.Row, Mypos.Col - 2] == WallClass.exist)
                        {
                            return false;
                        }
                        else return true;
                    }
                    else
                        return true;

                case PawnMove.Right:
                    if (gamestate.Wc_Col[Mypos.Row, Mypos.Col] == WallClass.exist)
                        return false;
                    else if (Mypos.Row == Enemypos.Row && (Mypos.Col - Enemypos.Col == -1))
                    {
                        if (Mypos.Col > 6)
                        {
                            return false;
                        }
                        else if (gamestate.Wc_Col[Mypos.Row, Mypos.Col + 1] == WallClass.exist)
                        {
                            return false;
                        }
                        else return true;
                    }
                    else
                        return true;

                default:
                    return false;

            }
        } */
    }
}
