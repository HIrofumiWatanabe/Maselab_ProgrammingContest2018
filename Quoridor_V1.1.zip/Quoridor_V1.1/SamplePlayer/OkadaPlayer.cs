﻿﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Procon2018.GameSystem;
using System.Diagnostics;
using System.Threading;
namespace Procon2018.GameInformation
{
    public class ccTestPlayer : AbstractPlayer
    {

        public ccTestPlayer()
            : base()
        {

        }

        public ccTestPlayer(string name)
            : base()
        {
            this.name = name;
        }

        public override Dicision getDicision()
        {
            //Debug.Write("start!!\n");
            Position mypos = GetPawnpos(FieldObject.P1);
            Position enemypos = GetPawnpos(FieldObject.P2);
            int p1w = GetWallnum(FieldObject.P1);
            int p2w = GetWallnum(FieldObject.P2);
            WallDir[,] mywalllist = GetWallState();
            WallClass[,] myhorwall = new WallClass[8, 9];
            WallClass[,] myvarwall = new WallClass[9, 8];
            int i,j;

            
            //Debug.Write("teigi!!\n");
            for (i = 0; i < 8; i++)
            {
                for (j = 0; j < 9; j++)
                {
                    myhorwall[i,j] = WallClass.blank;
       
                }
            }

            for (i = 0; i < 9; i++)
            {
                for (j = 0; j < 8; j++)
                {
                    myvarwall[i,j] = WallClass.blank;
                }
            }

            //Debug.Write("teigi2!!\n");
            for (i = 0; i < 8; i++)
            {
                for (j = 0; j < 8; j++)
                {
                    switch(mywalllist[i, j])
                    {
                        case WallDir.blank:
                            continue;
                        case WallDir.Horizontal2Goal:
                            myhorwall[i, j] = WallClass.exist;
                            myhorwall[i, j+1] = WallClass.exist;
                            break;
                        case WallDir.Vertical2Goal:
                            myvarwall[i, j] = WallClass.exist;
                            myvarwall[i+1,j] = WallClass.exist;
                            break;
                    }
                }
            }

            //Debug.Write("syokika!!");

            int seed = new Random().Next();
            seed = seed % 5;
            seed = seed % 3;
            Thread.Sleep(20);
            Dicision outdic = new Dicision();



            if(mypos.Row > 6)
            {
                seed = 0;
            }
            if (enemypos.Row > 6 && myhorwall[enemypos.Row,enemypos.Col]== WallClass.blank)
            {
                seed = 1;
            }
            if (p1w == 0)
            {
                seed = 0;
            }
            switch (seed)
            {
                case 0://最短距離で動く
                    outdic.DL= Dicision_label.dic_pawnmove;
                    break;
                case 1://敵の周囲に壁を置く
                    outdic.DL = Dicision_label.dic_wallset;
                    Debug.Write("enWallsetttttttttttt\n");
                    outdic.WS = enwallset(enemypos,myhorwall,myvarwall,mywalllist);
                    if (outdic.WS.WD == WallDir.blank)
                    {
                        outdic.DL = Dicision_label.dic_pawnmove;
                    }
                    break;
                case 2:
                    outdic.DL = Dicision_label.dic_wallset;
                    Debug.Write("myWallsetttttttttttt\n");
                    outdic.WS = mywallset(mypos, myhorwall, myvarwall, mywalllist);
                    if (outdic.WS.WD == WallDir.blank)
                    {
                        outdic.DL = Dicision_label.dic_pawnmove;
                    }
                    break;
                default:
                    outdic.DL= Dicision_label.dic_pawnmove;
                    break;
            }

            if(outdic.DL == Dicision_label.dic_pawnmove)
            {
                 Debug.Write("moveeeeeeeeeeeee\n");
                 outdic.PM = move(mypos,myhorwall,myvarwall);
            }
            return outdic;
        }

        private PawnMove move(Position myp, WallClass[,] myhorwall, WallClass[,] myvarwall)
        {
            PawnMove outpm = PawnMove.Up;

            int[,] wentlist = new int[9, 9];//各位置に行けるか判定用フラグ
            wentlist[myp.Row, myp.Col] = 1;//最初の自己位置は1
            //Queue<Position> posque = new Queue<Position>();
            //posque.Enqueue(myp);
            Position[] poslog = new Position[81];
            PawnMove[] moveclog = new PawnMove[81];
            
            int lognum = 0;
            int acnum = 0;
            Position tmppos = new Position(-1, -1);
            Position goalpos = new Position(-1, -1);

            poslog[lognum] = myp;
            wentlist[myp.Row, myp.Col] = 1;
            moveclog[lognum] = PawnMove.Up;
            lognum++;

            while (lognum >= acnum)
            {
                tmppos = poslog[acnum];
                acnum++;

                //下に広げる
                if (tmppos.Row <= 7)
                {
                    if (myhorwall[tmppos.Row, tmppos.Col] == WallClass.blank && wentlist[tmppos.Row + 1, tmppos.Col] == 0)
                    {
                        poslog[lognum] = new Position(tmppos.Row + 1, tmppos.Col);
                        moveclog[lognum] = PawnMove.Down;
                        lognum++;
                        wentlist[tmppos.Row + 1, tmppos.Col] = 1;
                    }
                }
                //右に広げる
                if (tmppos.Col <= 7)
                {
                    if (myvarwall[tmppos.Row, tmppos.Col] == WallClass.blank && wentlist[tmppos.Row, tmppos.Col + 1] == 0)
                    {
                        poslog[lognum] = new Position(tmppos.Row, tmppos.Col + 1);
                        moveclog[lognum] = PawnMove.Right;
                        lognum++;
                        wentlist[tmppos.Row, tmppos.Col + 1] = 1;
                        //   Debug.Write("PPP");
                    }
                }
                //左に広げる
                if (tmppos.Col >= 1)
                {
                    if (myvarwall[tmppos.Row, tmppos.Col - 1] == WallClass.blank && wentlist[tmppos.Row, tmppos.Col - 1] == 0)
                    {
                        poslog[lognum] = new Position(tmppos.Row, tmppos.Col - 1);
                        moveclog[lognum] = PawnMove.Left;
                        lognum++;
                        wentlist[tmppos.Row, tmppos.Col - 1] = 1;
                    }
                }
                //上に広げる
                if (tmppos.Row >= 1)
                {
                    if (myhorwall[tmppos.Row - 1, tmppos.Col] == WallClass.blank && wentlist[tmppos.Row - 1, tmppos.Col] == 0)
                    {
                        poslog[lognum] = new Position(tmppos.Row - 1, tmppos.Col);
                        moveclog[lognum] = PawnMove.Up;
                        if (tmppos.Row - 1 == 0)
                        {
                            goalpos = new Position(tmppos.Row - 1, tmppos.Col);
                            moveclog[lognum] = PawnMove.Up;
                            break;
                        }
                        lognum++;
                        wentlist[tmppos.Row - 1, tmppos.Col] = 1;
                    }
                }
            }
            for (int i = lognum; i >= 0; i--)
            {
                //if (goalpos.Equals(poslog[i]))
                if (goalpos.Row == poslog[i].Row && goalpos.Col == poslog[i].Col)
                {
                    //if (goalpos.Equals(myp))
                    if (goalpos.Row==myp.Row&& goalpos.Col==myp.Col)
                    {
                        break;
                    }
                    switch (moveclog[i])
                    {


                        case PawnMove.Up:
                            goalpos = new Position(poslog[i].Row + 1, poslog[i].Col);
                            outpm = PawnMove.Up;
                            break;
                        case PawnMove.Down:
                            goalpos = new Position(poslog[i].Row - 1, poslog[i].Col);
                            outpm = PawnMove.Down;
                            break;
                        case PawnMove.Left:
                            goalpos = new Position(poslog[i].Row, poslog[i].Col + 1);
                            outpm = PawnMove.Left;
                            break;
                        case PawnMove.Right:
                            goalpos = new Position(poslog[i].Row, poslog[i].Col - 1);
                            outpm = PawnMove.Right;
                            break;
                        default:
                            break;
                    }

                    
                }
            }

            return outpm;
        }

        private int randomenum(int max)
        {
            int myseed = new Random().Next();
            myseed = myseed % max + 1;
            Thread.Sleep(20);

            return myseed;
        }

        private WallSet enwallset(Position enp, WallClass[,] myhorwall, WallClass[,] myvarwall, WallDir[,] mypointwall)
        {

            int i = 0;
            int maxinum = 0;

            int emscore = 1;

            int[] horsetscore = new int[8];

            if (enp.Row == 7)
            {
                emscore = emscore * 10;
            }

            for (i = 0; i < 8; i++)
            {
                if (myhorwall[enp.Row, i] == WallClass.blank && myhorwall[enp.Row, i + 1] == WallClass.blank && mypointwall[enp.Row, i] == WallDir.blank)
                {
                    horsetscore[i] = 1*emscore;
                }
                else
                {
                    horsetscore[i] = 0;
                }
            }

            if (enp.Col == 0)
            {
                horsetscore[enp.Col] = horsetscore[enp.Col] * 8;
            }
            else if (enp.Col == 8)
            {
                horsetscore[enp.Col - 1] = horsetscore[enp.Col - 1] * 8;
            }
            else
            {
                horsetscore[enp.Col - 1] = horsetscore[enp.Col - 1] * 4 * emscore;
                horsetscore[enp.Col] = horsetscore[enp.Col] * 4 * emscore;
            }

            for (i = 0; i < 8; i++)
            {
                if (i < 6)
                {
                    if (mypointwall[enp.Row, i + 2] == WallDir.Horizontal2Goal)
                    {
                        horsetscore[i] = horsetscore[i] * 2;
                    }
                }
                if (i > 2)
                {
                    if (mypointwall[enp.Row, i - 2] == WallDir.Horizontal2Goal)
                    {
                        horsetscore[i] = horsetscore[i] * 2;
                    }
                }
            }

            int tmpmaxnum = -1;
            int iscore = -1;
            for (i = 0; i < 8; i++)
            {
                if (horsetscore[i] != 0)
                {
                    iscore = horsetscore[i] + randomenum(10);
                }
                if (tmpmaxnum < iscore)
                {
                    maxinum = i;
                    tmpmaxnum = iscore;
                }
            }

            //return mmws;

            //敵の最短ルートを探索
            int[,] wentlist = new int[9, 9];//各位置に行けるか判定用フラグ
            wentlist[enp.Row, enp.Col] = 1;//最初の自己位置は1
            //Queue<Position> posque = new Queue<Position>();
            //posque.Enqueue(myp);
            Position[] poslog = new Position[81];
            PawnMove[] moveclog = new PawnMove[81];
            int p1w = GetWallnum(FieldObject.P1);
            int p2w = GetWallnum(FieldObject.P2);
            int lognum = 0;
            int acnum = 0;
            Position tmppos = new Position(-1, -1);
            Position goalpos = new Position(-1, -1);

            poslog[lognum] = enp;
            wentlist[enp.Row, enp.Col] = 1;
            moveclog[lognum] = PawnMove.Up;
            lognum++;

            while (lognum >= acnum)
            {
                tmppos = poslog[acnum];
                acnum++;

                //下に広げる
                if (tmppos.Row <= 7)
                {
                    if (myhorwall[tmppos.Row, tmppos.Col] == WallClass.blank && wentlist[tmppos.Row + 1, tmppos.Col] == 0)
                    {
                        poslog[lognum] = new Position(tmppos.Row + 1, tmppos.Col);
                        moveclog[lognum] = PawnMove.Down;
                        if (tmppos.Row + 1 == 8)
                        {
                            goalpos = new Position(tmppos.Row + 1, tmppos.Col);
                            moveclog[lognum] = PawnMove.Down;
                            break;
                        }
                        lognum++;
                        wentlist[tmppos.Row + 1, tmppos.Col] = 1;
                    }
                }
                //右に広げる
                if (tmppos.Col <= 7)
                {
                    if (myvarwall[tmppos.Row, tmppos.Col] == WallClass.blank && wentlist[tmppos.Row, tmppos.Col + 1] == 0)
                    {
                        poslog[lognum] = new Position(tmppos.Row, tmppos.Col + 1);
                        moveclog[lognum] = PawnMove.Right;
                        lognum++;
                        wentlist[tmppos.Row, tmppos.Col + 1] = 1;
                        //   Debug.Write("PPP");
                    }
                }
                //左に広げる
                if (tmppos.Col >= 1)
                {
                    if (myvarwall[tmppos.Row, tmppos.Col - 1] == WallClass.blank && wentlist[tmppos.Row, tmppos.Col - 1] == 0)
                    {
                        poslog[lognum] = new Position(tmppos.Row, tmppos.Col - 1);
                        moveclog[lognum] = PawnMove.Left;
                        lognum++;
                        wentlist[tmppos.Row, tmppos.Col - 1] = 1;
                    }
                }
                //上に広げる
                if (tmppos.Row >= 1)
                {
                    if (myhorwall[tmppos.Row - 1, tmppos.Col] == WallClass.blank && wentlist[tmppos.Row - 1, tmppos.Col] == 0)
                    {
                        poslog[lognum] = new Position(tmppos.Row - 1, tmppos.Col);
                        moveclog[lognum] = PawnMove.Up;
                        lognum++;
                        wentlist[tmppos.Row - 1, tmppos.Col] = 1;
                    }
                }
            }
            //逆走していく
            int score = -100;
            List<int> verscore = new List<int>();
            List<Position> interrwallpos = new List<Position>();
            for (i = lognum; i >= 0; i--)
            {
                if (goalpos.Row == poslog[i].Row && goalpos.Col == poslog[i].Col)
                {
                    if (goalpos.Row == enp.Row && goalpos.Col == enp.Col)
                    {
                        break;
                    }
                    switch (moveclog[i])
                    {
                        case PawnMove.Up:
                            goalpos = new Position(poslog[i].Row + 1, poslog[i].Col);
                            break;
                        case PawnMove.Down:
                            goalpos = new Position(poslog[i].Row - 1, poslog[i].Col);
                            break;
                        case PawnMove.Left:
                            goalpos = new Position(poslog[i].Row, poslog[i].Col + 1);
                            if (poslog[i].Row > 0)
                            {
                                if (myvarwall[poslog[i].Row - 1, poslog[i].Col] == WallClass.blank && mypointwall[poslog[i].Row - 1, poslog[i].Col] == WallDir.blank)
                                {
                                    score = 1 + randomenum(12);
                                    verscore.Add(score);
                                    interrwallpos.Add(new Position(poslog[i].Row - 1,poslog[i].Col));
                                }
                            }
                            if (myvarwall[poslog[i].Row+1, poslog[i].Col] == WallClass.blank && mypointwall[poslog[i].Row, poslog[i].Col] == WallDir.blank)
                            {
                                score = 1 + randomenum(12);
                                verscore.Add(score);
                                interrwallpos.Add(new Position(poslog[i].Row, poslog[i].Col));
                            }
                            break;
                        case PawnMove.Right:
                            goalpos = new Position(poslog[i].Row, poslog[i].Col - 1);
                            if (poslog[i].Row > 0)
                            {
                                if (myvarwall[poslog[i].Row - 1, poslog[i].Col - 1] == WallClass.blank && mypointwall[poslog[i].Row - 1, poslog[i].Col - 1] == WallDir.blank)
                                {
                                    score = 1 + randomenum(12);
                                    verscore.Add(score);
                                    interrwallpos.Add(new Position(poslog[i].Row - 1,poslog[i].Col - 1));
                                }
                            }
                            if (myvarwall[poslog[i].Row+1, poslog[i].Col - 1] == WallClass.blank && mypointwall[poslog[i].Row, poslog[i].Col - 1] == WallDir.blank)
                            {
                                score = 1 + randomenum(12);
                                verscore.Add(score);
                                interrwallpos.Add(new Position(poslog[i].Row, poslog[i].Col - 1));
                            }
                            break;
                        default:
                            break;
                    }


                }
            }
            verscore.Add(-100);
            int varmaxscor = verscore.Max();

            if (tmpmaxnum >= varmaxscor)
            {
                WallSet mmws = new WallSet(new Position(enp.Row, maxinum), WallDir.blank);
                if (tmpmaxnum >= 1)
                {
                    mmws.WD = WallDir.Horizontal2Goal;
                }
                return mmws;
            }
            else
            {
                int tmplistnum = verscore.IndexOf(varmaxscor);
                WallSet mmws = new WallSet(interrwallpos[tmplistnum], WallDir.Vertical2Goal);
                return mmws;
            }
        }

        private WallSet mywallset(Position myp, WallClass[,] myhorwall, WallClass[,] myvarwall, WallDir[,] mypointwall)
        {
            if (myp.Row == 8)
            {
                return new WallSet(new Position(-1, -1), WallDir.blank);
            }


            int i = 0;
            int maxinum = 0;

            int[] horsetscore = new int[8];

            for (i = 0; i < 8; i++)
            {
                if (myhorwall[myp.Row, i] == WallClass.blank && myhorwall[myp.Row, i + 1] == WallClass.blank && mypointwall[myp.Row, i] == WallDir.blank)
                {
                    horsetscore[i] = 1;
                }
                else
                {
                    horsetscore[i] = 0;
                }
            }

            if (myp.Col == 0)
            {
                horsetscore[myp.Col] = horsetscore[myp.Col] * 8;
            }
            else if (myp.Col == 8)
            {
                horsetscore[myp.Col - 1] = horsetscore[myp.Col - 1] * 8;
            }
            else
            {
                for (i = 0; i < 8; i++)
                {
                    if (i < 6)
                    {
                        if (mypointwall[myp.Row, i + 2] == WallDir.Horizontal2Goal)
                        {
                            horsetscore[i] = horsetscore[i] * 4;
                        }
                    }
                    if (i > 2)
                    {
                        if (mypointwall[myp.Row, i - 2] == WallDir.Horizontal2Goal)
                        {
                            horsetscore[i] = horsetscore[i] * 4;
                        }
                    }
                }
            }

            int tmpmaxnum = -1;
            int iscore = -1;
            for (i = 0; i < 8; i++)
            {
                if (horsetscore[i] != 0)
                {
                    iscore = horsetscore[i] + randomenum(10);
                }
                if (tmpmaxnum < iscore)
                {
                    maxinum = i;
                    tmpmaxnum = iscore;
                }
            }

            WallSet mmws = new WallSet(new Position(myp.Row, maxinum), WallDir.blank);
            if (maxinum >= 1)
            {
                mmws.WD = WallDir.Horizontal2Goal;
            }
            return mmws;
        }

    }
}