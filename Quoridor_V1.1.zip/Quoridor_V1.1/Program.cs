﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Procon2018.GameInformation;
using Procon2018.GameSystem;


namespace Procon2018
{
    /// <summary>
    /// App.xaml の相互作用ロジック
    /// </summary>
    static class Program
    {

        [STAThread]
        public static void Main()
        {

            App app = new App();
            GameManager gm = new GameManager(new ccTestPlayer("Jin"), new ccTestPlayer("Okada"), 100000, 10000, 1);
            app.InitializeComponent();

            app.Run(new QuoridorUI(gm));
        }
    }
}
